using System;

namespace HelloWorld
{
    class Hello
    {
        static void Main()
        {
            Console.WriteLine("Hello");
            // configuration file config.cfg
        }
    }
}